package com.diceyas.usagestats.db;

/**
 * Created by youansheng on 2016/6/3.
 */
public class RemoteDataBase {

    public static void update() {

    }
}

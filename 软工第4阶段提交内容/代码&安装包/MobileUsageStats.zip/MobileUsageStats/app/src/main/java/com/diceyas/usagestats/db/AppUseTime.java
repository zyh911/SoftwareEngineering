package com.diceyas.usagestats.db;

/**
 * Created by Administrator on 2016/5/29 0029.
 */
public class AppUseTime
{
    public String pkgName;
    public int time;
}
